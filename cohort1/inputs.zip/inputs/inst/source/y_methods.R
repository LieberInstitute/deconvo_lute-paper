#!/usr/bin/env R

# 
# Methods for the y mixed signals matrices. These have standard dimensions [G,J]
# for G gene marker features and J samples.
#
